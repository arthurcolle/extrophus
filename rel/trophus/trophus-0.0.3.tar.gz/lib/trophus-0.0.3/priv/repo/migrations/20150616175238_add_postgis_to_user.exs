defmodule Trophus.Repo.Migrations.AddPostgisToUser do
  use Ecto.Migration
  
  def up do
  end
#     alter table(:users) do
#       add :loc, :geometry
#     end
#   end

#   def down do
#     alter table(:users) do
#       remove :loc
#     end
#   end
end
